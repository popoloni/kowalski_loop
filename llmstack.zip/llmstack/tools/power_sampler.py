"""Power sampling utilities for TCO analysis on Apple Silicon Macs.

Provides:
- is_laptop(): detect if this Mac has a battery (laptop vs desktop)
- get_battery_info(): battery percent, plugged status, secs left (desktop returns None)
- sample_powermetrics(): parse `powermetrics --samplers gpu,cpu_power` output
- write_power_csv(): append to logs/power_metrics.csv
- compute_session_energy(): aggregate energy/cost from timings + power data
"""
import csv
import os
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

import psutil

# Powermetrics output patterns (macOS Sonoma+)
RE_GPU_POWER = r"GPU Power\s+([\d.]+)\s+W"
RE_CPU_POWER = r"CPU Power\s+([\d.]+)\s+W"
RE_TOTAL_POWER = r"System Power\s+([\d.]+)\s+W"
RE_THERMAL = r"Thermal\s+(.+)"
RE_FAN_RPM = r"Fan Speed\s+([\d.]+)\s+RPM"
RE_GPU_ACTIVE = r"GPU Active\s+([\d.]+)%"
RE_SOC_TEMP = r"SoC Temperature\s+([\d.]+)\s+C"
RE_CPU_TEMP = r"CPU Temperature\s+([\d.]+)\s+C"


def is_laptop() -> bool:
    """Return True if this Mac has a battery (laptop/iPad).

    On desktop Macs (Mac Mini, Mac Studio), returns False.
    """
    try:
        bat = psutil.sensors_battery()
        if bat is None:
            return False
        # On plugged-in desktops, secsleft is POWER_TIME_UNLIMITED (-2)
        if hasattr(psutil, "POWER_TIME_UNLIMITED"):
            return bat.secsleft != psutil.POWER_TIME_UNLIMITED
        # Fallback: check if percent is None
        return bat.percent is not None
    except Exception:
        return False


def get_battery_info() -> dict | None:
    """Return battery dict, or None on desktop Macs.

    Returns:
        {"percent": int, "plugged": bool, "secsleft": int} or None
    """
    if not is_laptop():
        return None
    try:
        bat = psutil.sensors_battery()
        if bat is None:
            return None
        return {
            "percent": bat.percent,
            "plugged": bool(bat.power_plugged),
            "secsleft": bat.secsleft,
        }
    except Exception:
        return None


def _run_powermetrics(samples: int = 1, interval: float = 1.0) -> str | None:
    """Run powermetrics and return stdout, or None on failure.

    Tries with sudo first, falls back to no-sudo.
    """
    for use_sudo in (True, False):
        cmd = ["powermetrics", "--samplers", "gpu,cpu_power", "-i", str(interval), "-n", str(samples)]
        if use_sudo:
            cmd = ["sudo"] + cmd
        try:
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=15
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout
            # If sudo failed with permission error, try without
            if use_sudo and ("permission" in result.stderr.lower() or "denied" in result.stderr.lower()):
                continue
        except subprocess.TimeoutExpired:
            if use_sudo:
                continue
        except Exception:
            if use_sudo:
                continue
    return None


def parse_powermetrics(output: str) -> dict:
    """Parse powermetrics output into a structured dict.

    Returns dict with keys: gpu_power_w, cpu_power_w, total_power_w,
    thermal_state, fan_rpm, gpu_active_pct, soc_temp_c, cpu_temp_c.
    All numeric values are floats or None if not found.
    """
    import re as _re

    result = {
        "gpu_power_w": None,
        "cpu_power_w": None,
        "total_power_w": None,
        "thermal_state": None,
        "fan_rpm": None,
        "gpu_active_pct": None,
        "soc_temp_c": None,
        "cpu_temp_c": None,
    }

    patterns = {
        RE_GPU_POWER: "gpu_power_w",
        RE_CPU_POWER: "cpu_power_w",
        RE_TOTAL_POWER: "total_power_w",
        RE_THERMAL: "thermal_state",
        RE_FAN_RPM: "fan_rpm",
        RE_GPU_ACTIVE: "gpu_active_pct",
        RE_SOC_TEMP: "soc_temp_c",
        RE_CPU_TEMP: "cpu_temp_c",
    }

    for pattern, key in patterns.items():
        m = _re.search(pattern, output)
        if m:
            val = m.group(1).strip()
            if key in ("thermal_state",):
                result[key] = val
            else:
                try:
                    result[key] = float(val)
                except (ValueError, TypeError):
                    pass

    return result


def sample_powermetrics() -> dict:
    """Take a single powermetrics sample and return parsed dict.

    Returns empty dict if sampling fails (e.g., no sudo, desktop Mac).
    """
    output = _run_powermetrics(samples=1, interval=1.0)
    if output is None:
        return {}
    return parse_powermetrics(output)


def get_powermetrics_csv_path(log_dir: str = "logs") -> Path:
    """Return the path to the power metrics CSV file."""
    base = Path(log_dir)
    base.mkdir(parents=True, exist_ok=True)
    return base / "power_metrics.csv"


def write_power_sample(log_dir: str = "logs", sample: dict | None = None) -> None:
    """Append a power metrics sample to logs/power_metrics.csv.

    If sample is None or empty, writes a row with all N/A values.
    """
    csv_path = get_powermetrics_csv_path(log_dir)
    power_csv_header = [
        "timestamp",
        "gpu_power_w",
        "cpu_power_w",
        "total_power_w",
        "thermal_state",
        "fan_rpm",
        "gpu_active_pct",
        "soc_temp_c",
        "cpu_temp_c",
    ]

    now = datetime.now(timezone.utc).isoformat()

    if sample and any(v is not None for v in sample.values()):
        row = [
            now,
            sample.get("gpu_power_w") or "",
            sample.get("cpu_power_w") or "",
            sample.get("total_power_w") or "",
            sample.get("thermal_state") or "",
            sample.get("fan_rpm") or "",
            sample.get("gpu_active_pct") or "",
            sample.get("soc_temp_c") or "",
            sample.get("cpu_temp_c") or "",
        ]
    else:
        row = [now] + [""] * (len(power_csv_header) - 1)

    new = (not csv_path.exists()) or csv_path.stat().st_size == 0
    with open(csv_path, "a", newline="") as f:
        w = csv.writer(f)
        if new:
            w.writerow(power_csv_header)
        w.writerow(row)
        f.flush()


def compute_session_energy(
    timings_csv: str,
    power_csv: str | None = None,
    hardware: dict | None = None,
) -> dict:
    """Aggregate energy and cost data from timings + power CSVs.

    Returns a dict suitable for session_summary.jsonl:
    {
        "total_prompt_tokens": int,
        "total_decode_tokens": int,
        "total_energy_kwh": float,
        "energy_cost_usd": float,
        "cloud_equivalent_usd": float,
        "savings_usd": float,
        "thermal_throttle_minutes": float,
        "peak_gpu_power_w": float,
        "avg_gpu_power_w": float,
    }
    """
    import pandas as pd

    if hardware is None:
        hardware = {}

    # Read timings CSV
    timings_path = Path(timings_csv)
    if not timings_path.exists():
        return {}

    df = pd.read_csv(timings_path)

    total_prompt = int(df["prompt_tokens"].sum()) if "prompt_tokens" in df.columns else 0
    total_decode = int(df["decode_tokens"].sum().fillna(0)) if "decode_tokens" in df.columns else 0

    # Read power CSV if available
    total_energy_kwh = 0.0
    peak_gpu_power = 0.0
    avg_gpu_power = 0.0
    thermal_throttle_minutes = 0.0

    if power_csv and Path(power_csv).exists():
        power_df = pd.read_csv(power_csv)

        if "gpu_power_w" in power_df.columns:
            gpu_powers = power_df["gpu_power_w"].dropna()
            if not gpu_powers.empty:
                avg_gpu_power = float(gpu_powers.mean())
                peak_gpu_power = float(gpu_powers.max())

                # Estimate energy: assume each power sample represents ~1 second
                # (powermetrics -n 1 -i 1 takes 1 sample per second)
                total_watt_seconds = float(gpu_powers.sum())
                total_energy_kwh = total_watt_seconds / 3600.0  # Wh to kWh

        # Count thermal throttle time
        if "thermal_state" in power_df.columns:
            throttle_rows = power_df[power_df["thermal_state"].str.contains("Throttled", case=False, na=False)]
            thermal_throttle_minutes = float(len(throttle_rows))  # each sample = ~1 second

    # Compute costs
    grid_cost_kwh = float(hardware.get("avg_grid_cost_kwh", 0.15))
    energy_cost_usd = total_energy_kwh * grid_cost_kwh

    # Cloud API pricing estimates (per 1M tokens, approximate frontier pricing)
    cloud_cost_per_m_prompt = 2.50  # e.g., Claude Pro
    cloud_cost_per_m_decode = 10.0  # e.g., Claude Pro

    total_prompt_m = total_prompt / 1_000_000
    total_decode_m = total_decode / 1_000_000
    cloud_equivalent_usd = (total_prompt_m * cloud_cost_per_m_prompt) + (total_decode_m * cloud_cost_per_m_decode)

    savings_usd = cloud_equivalent_usd - energy_cost_usd

    return {
        "total_prompt_tokens": total_prompt,
        "total_decode_tokens": total_decode,
        "total_energy_kwh": round(total_energy_kwh, 6),
        "energy_cost_usd": round(energy_cost_usd, 4),
        "cloud_equivalent_usd": round(cloud_equivalent_usd, 2),
        "savings_usd": round(savings_usd, 2),
        "thermal_throttle_minutes": round(thermal_throttle_minutes, 1),
        "peak_gpu_power_w": round(peak_gpu_power, 1),
        "avg_gpu_power_w": round(avg_gpu_power, 1),
    }


def compute_break_even_volume(hardware: dict) -> float:
    """Compute the monthly token volume at which local inference breaks even vs cloud.

    Returns break-even in tokens per month.
    """
    purchase_price = float(hardware.get("purchase_price_usd", 0))
    life_years = float(hardware.get("expected_life_years", 5))
    grid_cost_kwh = float(hardware.get("avg_grid_cost_kwh", 0.15))

    if purchase_price == 0 or life_years == 0:
        return float("inf")

    # Amortized monthly hardware cost
    monthly_amortization = purchase_price / (life_years * 12)

    # Average energy cost per 1M tokens (from measured data, default estimate)
    avg_energy_per_m_tokens_kwh = 0.05  # ~50 Wh per 1M tokens (estimate)
    energy_cost_per_m_tokens = avg_energy_per_m_tokens_kwh * grid_cost_kwh

    # Cloud cost per 1M tokens (blended prompt+decode)
    cloud_cost_per_m_tokens = 5.0  # rough average

    cost_savings_per_m_tokens = cloud_cost_per_m_tokens - energy_cost_per_m_tokens

    if cost_savings_per_m_tokens <= 0:
        return float("inf")

    break_even_tokens = (monthly_amortization / cost_savings_per_m_tokens) * 1_000_000
    return break_even_tokens
